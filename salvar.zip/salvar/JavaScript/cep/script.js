function preencherEndereco()
{
    // Obtém o valor do CEP inserido pelo usuário
    var cep = document.getElementById('cep').value;

    // Constrói a URL para fazer a requisição com base no CEP fornecido
    var url = 'https://viacep.com.br/ws/' + cep + '/json/';

    // Faz uma requisição fetch para a URL construída
    fetch(url)
        .then(response =>
            // Verifica se a resposta da requisição está ok 
            {
                if(!response.ok)
                {
                    // Se a resposta não estiver OK, lança um erro
                    throw new Error('Erro ao buscar o CEP. Verifique se o CEP é válido.');
                }
                return response.json();
            })
            .then(data =>
                // Quando os dados JSON forem recebidos com sucesso, preenche os campos de endereço no formulário com os dados obtidos
                {
                    document.getElementById('logradouro').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                    document.getElementById('estado').value = data.uf;
                })
                .catch(error =>
                    // Se ocorrer algum errro durante o processo, ele é capturado aqui e tratado
                    {
                        console.error('Erro: ', error);
                        alert(error);
                    })
}