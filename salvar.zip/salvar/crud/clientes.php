<?php
    // Inclui o arquivo de conexão ao banco de dados
    include("conexao.php");

    // Query SQL para selecionar todos os usuários
    $result_cliente = "SELECT * FROM usuarios";

    // Executa a query no banco de dados
    $resultado_cliente = mysqli_query($conn, $result_cliente);

    // Obtém a primeira linha do resultado como uma matriz associativa
    $linha = mysqli_fetch_assoc($resultado_cliente);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem de Usuários</title>
</head>
<body>

<div id="tabela">

<!-- Tabela HTML para exibir a lista de usuários -->
    <table border="1px" cellpadding="6px" cellspacing="0">

        <tr>
            <th>ID</th>
            <th>NOME</th>
            <th>EMAIL</th>
            <th colspan="2">SELECIONE</th>
        </tr>

<?php
//Loop para exibir cada linha da tabela de usuários 
do{
?>

        <!-- Linha da tabela exibindo informações do usuário -->
        <tr>
            <td><?php echo $linha ['id'] ?></td>
            <td><?php echo $linha ['nome'] ?></td>
            <td><?php echo $linha ['email'] ?></td>
        
<!-- Links para as páginas alterar e excluir, passando o ID do usuário como parâmetro na URL -->
            <td><a href="alterar.php?id=<?php echo $linha ['id'] ?>">Alterar</a></td>
            <td><a href="excluir.php?id=<?php echo $linha ['id'] ?>">Excluir</a></td>
        </tr>

<!-- Retorna uma matriz associativa que corresponde a linha obtida, ou null se não houverem mais linhas    -->
<?php } while($linha = mysqli_fetch_assoc($resultado_cliente)); ?>
    
    </table>
<br>
<!-- Botão para inserir um novo usuário -->
<button><a href="index.php">Inserir novo</a></button>

</div>
</body>
</html>