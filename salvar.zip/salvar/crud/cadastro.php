<?php
    // Inclui o arquivo de conexão ao banco de dados
    include("conexao.php");

    // Obtêm os valores do formulário enviado via POST
    $nome_cliente_usuario = $_POST['nome_cliente'];
    $email_cliente_usuario = $_POST['email_cliente'];
    
    // Monta a query SQL para inserir um novo usuário no banco de dados    
    $result_usuario = "INSERT INTO clientes(nome_cliente, email_cliente) VALUES ('$nome_cliente_usuario','$email_cliente_usuario')";

    // Executa a query no banco de dados
    $resultado_usuario = mysqli_query($conn, $result_usuario);
    // Verifica se a operação de inserção afetou alguma linha no banco de dados    
    if(mysqli_affected_rows($conn) != 0){
        //Se a operação foi bem-sucedida, redireciona para a página inicial e exibe um alerta
        echo"
        <META HTTP-EQUIV=REFRESH CONTENT ='0;URL=http://localhost/uc13/crud/index.php'>
        <script type=\"text/javascript\">
            alert(\"Usuário cadastrado com Sucesso.\");
        </script>
    ";
    }else{
        echo"
        <META HTTP-EQUIV=REFRESH CONTENT ='0;URL=http://localhost/uc13/crud/index.php'>
        <script type=\"text/javascript\">
            alert(\"O Usuário não foi cadastrado com Sucesso.\");
        </script>
    ";
    }
?>