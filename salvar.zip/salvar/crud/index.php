<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuários</title>

    <!-- Função em javascript para validar o formulário de cadastro -->
    <script type="text/javascript">
    function validar_form(){
        // Obtém os valores dos campos de nome email
        var nome = form_cadastro.nome.value;
        var email = form_cadastro.email.value;

        // Verifica se o campo nome está vazio
        if(nome == ""){
            alert("Campo nome obrigatório");
            form_cadastro.nome.focus();
            return false;
        }

        // Verifica se o campo email está vazio
        if(email == ""){
            alert("Campo email obrigatório");
            form_cadastro.email.focus();
            return false;
        }

        if(
        form_cadastro.email.value.indexOf("@") == -1 ||
        form_cadastro.email.value.indexOf(".") == -1 ||
        form_cadastro.email.value == "" ||
        form_cadastro.email.value == null) {
            alert("Por favor, indique um email válido.");
        form_cadastro.email.focus();
        return false;
        }
    }    
    </script>

</head>
<body>
    <!-- Início do formulário de cadastro -->
    <div class="formulario">
        <form name="form_cadastro" method="POST" action="cadastro.php">
            <!-- Campo para inserir o nome -->
            Nome: <input type="text" name="nome" placeholder="Digite o nome completo" ><br><br>
            <!-- Campo para inserir o email -->
            E-mail: <input type="email" name="email" placeholder="Digite o email"><br><br>
            <!-- Botão de envio do formulário -->
            <input type="submit" value="Cadastrar" onclick="return validar_form()">
        </form><br>
        <?php
        
        $hoje = date('d/m/Y');

        echo 'Hoje é: ' . $hoje;
        ?>
        <br><br>
        
        <!-- Botão para listar usuários -->
        <button><a href="clientes.php">Listar usuários</a></button>
    </div>
</body>
</html>