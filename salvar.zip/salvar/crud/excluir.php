<?php
    include("conexao.php");

    // Verifica se o parâmetro 'id_cliente' está definido na URL e não está vazia
    if(isset($_GET['id_cliente']) && $_GET['id_cliente'] != ''){
        $id_cliente = $_GET['id_cliente']; 

        // Consulta o banco de dados para obter o nome do usuário com o ID fornecido
        $result_usuario = "SELECT nome FROM usuarios WHERE id=$id";
        $resultado_usuario = mysqli_query($conn, $result_usuario);
        $linha = mysqli_fetch_assoc($resultado_usuario);
    }

    // Verifica se o formulário foi submetido e se o campo 'exclui' está definido como 'exclui_usuario'
    if(isset($_POST['exclui']) && $_POST['exclui'] == 'exclui_cliente'){
        $id_cliente = $_POST['id_cliente$id_cliente'];

        // Verifica se o campo 'excluir' está definido como 'SIM' no formulário   
        if(isset($_POST['excluir']) && $_POST['excluir'] == 'SIM'){
            
            // Monta a query SQL para excluir o usuário do bd
            $sql = "DELETE FROM clientes WHERE id_cliente='$id_cliente'";

            // Executa a query no banco de dados
            if(mysqli_query($conn, $sql)){
                // Se a exclusão foi bem-sucedida, redireciona para página de usuários
                header('Location: clientes.php');
            }
            else{
                // Se houver um erro na exclusão, exiba uma mensagem de erro
                echo "ERRO: " . $sql . "<br>" . mysqli_error($conn);
            }
        }
        else{
            // Se o usuário optar por não excluir, redireciona para a página de usuários
            header('Location:clientes.php');
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exclusão de Usuário</title>
</head>
<body>
    <!-- Exibe uma mensagem para confirmar a exclusão do usuário -->
    <p>Você confirma a exclusão do usuário: <br><br><?php echo $linha['nome'] ?>?</p>

    <!-- Formulário para confirmar ou cancelar a exclusão do usuário -->
    <form action="" method="POST">
        <!-- Campos ocultos para indicar a ação de exclusão e o ID do usuário -->
        <input type="hidden" name="exclui" value="exclui_cliente">
        <input type="hidden" name="id" value="<?php echo $id ?>">

        <!-- Botões para confirmar ou cancelar a exclusão -->
        <input type="submit" name="excluir" value="SIM">
        <input type="submit" name="excluir" value="NÃO">
    </form>

    
</body>
</html>