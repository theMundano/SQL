<?php
    include("conexao.php");

    // Verifica se a variável 'id_cliente' está definida na URL e não está vazia
    if(isset($_GET['id_cliente']) && $_GET["id_cliente"] != ''){
        $id_cliente = $_GET['id_cliente'];
        // Consulta o bd para obter os dados do usuário com id_cliente fornecido
        $result_usuario = "SELECT * FROM clientes WHERE id_cliente=$id_cliente";
        $resultado_usuario = mysqli_query($conn,$result_usuario);
        $linha = mysqli_fetch_assoc($resultado_usuario);
    }

    // Verifica  se o formulario foi submetido e se o campo 'altera' está definido como 'altera_usuario'
    if(isset($_POST['altera']) && $_POST['altera'] == 'altera_usuario'){
        $id_cliente = $_POST['id_cliente'];
        $nome_cliente = $_POST['nome_cliente'];
        $email_cliente = $_POST['email_cliente'];

        // Atualiza os dados do usuário no bd
        $sql = "UPDATE clientes SET nome_cliente='$nome_cliente', email_cliente='$email_cliente' WHERE id_cliente='$id_cliente'";
        // Verifica se a consulta foi bem sucedida e redireciona para a página de usuários
        if(mysqli_query($conn,$sql)){
            header('Location:clientes.php');
        }
        else{
            echo "ERRO: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de Usuários</title>

</head>
<body>
    <!-- Início do formulário de cadastro -->
    <div class="formulario">
        <form method="POST" action="">
            <!-- Campo para alterar o nome_cliente -->
            nome_cliente: <input type="text" name="nome_cliente" value="<?php echo $linha['nome_cliente'] ?>"><br><br>

            <!-- Campo para alterar o email_cliente -->
            E-mail: <input type="text" name="email_cliente" value="<?php echo $linha['email_cliente'] ?>"><br><br>

            <!-- Campos ocultos para indicar a ação de alteração eo id_cliente do usuário -->
            <input type="hidden" name="altera" value="altera_usuario">
            <input type="hidden" name="id_cliente" value="<?php echo $id_cliente ?>">

            <!-- Botão de envio do formulário -->
            <input type="submit" name="alterar" value="Alterar">
        </form><br>    
        <br><br>
    </div>
</body>
</html>